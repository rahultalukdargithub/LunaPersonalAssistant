from setuptools import setup

setup(name = "GoogleImageScrapper",
author = "kaushik shresth",
version = "0.1.0",
packages = ['GoogleImageScrapper'])

